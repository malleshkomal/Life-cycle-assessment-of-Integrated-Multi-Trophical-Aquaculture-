"""IMTA circular KPI decision tool.

Reads the foreground LCI (data/lci/dataset/imta-cirkpi-lci.csv), the parameters and a table of
impact factors, then computes for each scenario:
  1. impact assessment (amount x factor),
  2. economic allocation to the sea bream,
  3. 12 KPIs in three dimensions (environment, circularity, economy) with targets.

Usage:  python tool/kpi_tool.py            (illustrative factors)
        python tool/kpi_tool.py --factors my_factors.csv   (e.g. factors calculated per unit in openLCA)
The factors shipped with this repo are ILLUSTRATIVE. Replace them with per-unit results from your
own LCA database (1 unit of each input calculated in openLCA) for real results.
"""
import argparse, csv
from collections import defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

def read_csv(p):
    with open(p, newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--factors", default=ROOT / "tool" / "factors_illustrative.csv")
    ap.add_argument("--out", default=ROOT / "tool" / "kpi_results.csv")
    a = ap.parse_args()

    lci = read_csv(ROOT / "data" / "lci" / "dataset" / "imta-cirkpi-lci.csv")
    par = {r["par_name"]: float(r["par_amount"]) for r in read_csv(ROOT / "data" / "lci" / "dataset" / "parameters.csv")}
    fac = {r["flow"]: (float(r["climate_kgCO2eq_per_unit"]), float(r["marine_eutrophication_kgNeq_per_unit"])) for r in read_csv(a.factors)}

    inv = defaultdict(dict)
    for r in lci:
        inv[r["ap_code"]][r["fp_name"]] = (r["fp_type"], float(r["fp_amount"]))

    feed = ["fishmeal, 63-65% protein", "fish oil, from anchovy", "soybean meal", "wheat grain, feed", "rape oil, crude"]
    out = []
    for code in sorted(inv):
        x = inv[code]
        amt = lambda f: x.get(f, (None, 0.0))[1]
        cc = eu = cc_feed = 0.0
        for f, (t, v) in x.items():
            if t == "production":
                continue
            sign = -1 if t == "avoided product" else 1
            c, e = fac.get(f, (0.0, 0.0))
            cc += sign * v * c; eu += sign * v * e
            if f in feed:
                cc_feed += v * c
        fish, sw, mu = amt("Sea bream, fresh, at farm gate"), amt("Seaweed, fresh, at farm gate"), amt("Mussels, fresh, at farm gate")
        rev = {"fish": fish * par["price_fish"], "sw": sw * par["price_seaweed"], "mu": mu * par["price_mussels"]}
        share_fish = rev["fish"] / sum(rev.values())
        residues = par["seaweed_residues"] if amt("composting, seaweed residues") > 0 else 0.0
        shells = amt("ground limestone (avoided)")
        # nutrient balance
        n_feed, p_feed = par["feed_total"] * par["N_feed"], par["feed_total"] * par["P_feed"]
        n_fish, p_fish = fish * par["N_fish"], fish * par["P_fish"]
        n_ext = (sw + residues) * par["N_seaweed"] + mu * par["N_mussels"]
        p_ext = (sw + residues) * par["P_seaweed"] + mu * par["P_mussels"]
        potential = (par["seaweed_residues"] if sw > 0 else 0) + mu * par["shell_share"]
        k = {
            "E1 Carbon footprint of fish [kg CO2-eq/kg]": (cc * share_fish / fish, "lower", 2.0),
            "E2 Marine eutrophication of fish [kg N-eq/kg]": (eu * share_fish / fish, "lower", 0.08),
            "E4 Feed share of climate impact [-]": (cc_feed / cc, "lower", 0.75),
            "C1 Nitrogen recovery rate [-]": (n_ext / (n_feed - n_fish), "higher", 0.15),
            "C2 Phosphorus recovery rate [-]": (p_ext / (p_feed - p_fish), "higher", 0.10),
            "C3 Nitrogen use efficiency [-]": ((n_fish + n_ext) / n_feed, "higher", 0.35),
            "C4 Feed conversion ratio [kg/kg]": (par["feed_total"] / fish, "lower", 1.7),
            "C5 Share of non-fed biomass [-]": ((sw + mu) / (fish + sw + mu), "higher", 0.5),
            "C6 By-product valorisation rate [-]": ((residues + shells) / potential if potential else 0.0, "higher", 0.5),
            "B1 Eco-efficiency [EUR/t CO2-eq]": (sum(rev.values()) / (cc / 1000), "higher", 3000),
            "B2 Revenue share of extractive species [-]": ((rev["sw"] + rev["mu"]) / sum(rev.values()), "higher", 0.25),
        }
        for name, (val, better, target) in k.items():
            met = val <= target if better == "lower" else val >= target
            out.append({"scenario": code, "kpi": name, "value": round(val, 4), "better_if": better, "target": target, "met": met})
        out.append({"scenario": code, "kpi": "Farm total climate change [kg CO2-eq/yr]", "value": round(cc, 1), "better_if": "lower", "target": "", "met": ""})
    with open(a.out, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(out[0])); w.writeheader(); w.writerows(out)
    # console summary
    scen = sorted({r["scenario"] for r in out})
    print(f"{'KPI':52s}" + "".join(f"{s:>14s}" for s in scen))
    for kpi in dict.fromkeys(r["kpi"] for r in out):
        vals = {r["scenario"]: r for r in out if r["kpi"] == kpi}
        print(f"{kpi:52s}" + "".join(f"{vals[s]['value']:>12}{' ✓' if vals[s]['met'] is True else (' ✗' if vals[s]['met'] is False else '  ')}" for s in scen))
    for s in scen:
        n = sum(1 for r in out if r["scenario"] == s and r["met"] is True); t = sum(1 for r in out if r["scenario"] == s and r["met"] != "")
        print(f"{s}: {n} of {t} targets met")
    print(f"\nWritten: {a.out}")

if __name__ == "__main__":
    main()
