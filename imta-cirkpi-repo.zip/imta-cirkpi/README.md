# Life cycle assessment of fish monoculture and IMTA aquaculture
### A circular KPI decision tool (demonstration)

A small, fully transparent example of a **circular KPI decision workflow** for aquaculture:
from a life cycle inventory (LCI), through life cycle assessment (LCA) in openLCA, to a
**KPI framework** that compares design options on environment, circularity and economy.

The case is a gilthead sea bream farm in Portugal, compared in two designs:

| Scenario | Design |
|---|---|
| **A** | Fish monoculture |
| **C** | IMTA (integrated multi-trophic aquaculture: fish + seaweed + mussels) **with waste valorisation**: seaweed residues composted, mussel shells reused as lime |

> **Status: demonstration / teaching example (v0.1.0).**
> Activity data are **assumptions** checked against literature ranges, not measured farm data.
> The illustrative factors in `tool/` are **not** ecoinvent values. Real ecoinvent results are in
> `data/openlca_results/` and have **known issues** (see [`docs/known_issues.md`](docs/known_issues.md)).
> Do not use the numbers for decisions about real farms.

## Key findings (so far)

1. **Feed dominates the climate impact** (about two thirds with illustrative factors). In the ecoinvent
   run, **land use change from Brazilian soy** in the feed is a major contributor (about 11–30 % depending on the run).
2. **IMTA with waste valorisation (C) lowers impact per kg of fish** (2.90 → 2.12 kg CO2-eq/kg, illustrative) and recovers
   about 18 % of the nitrogen released by the fish, but **total farm emissions rise** by about 9 % (more energy, boats, ropes,
   transport): an absolute-vs-relative trade-off.
3. **Waste valorisation improves circularity KPIs strongly** (by-product valorisation 0 % → 100 %) but its own climate
   effect is marginal (+460 / −400 kg CO2-eq per year) compared with feed (84,300 kg CO2-eq).
4. **Model checks matter:** in openLCA, auto-linking chose a lignite-dominated electricity mix instead of
   Portugal, and the farm's nitrogen emission had no characterisation factor in the EF 3.1 (adapted) method.

→ A circular decision tool needs **circularity KPIs and LCA KPIs side by side**, transparent allocation,
and automatic checks of providers and characterisation factors.

![KPI comparison](figures/kpi_E1_vs_C1.png)

## Repository structure

```
imta-cirkpi/
├── README.md                     this file
├── CITATION.cff                  how to cite this repository (and the LCI schema paper)
├── LICENSE                       MIT (code) – data under CC BY 4.0, see LICENSE
├── requirements.txt
├── docs/
│   ├── goal_and_scope.md         LCA of fish monoculture and IMTA aquaculture – goal and scope (ISO 14040/44)
│   ├── methodology.md            LCI → LCIA → allocation → KPIs, with formulas
│   └── known_issues.md           open problems and limitations
├── data/
│   ├── lci/                      foreground LCI in LCIS2024 structure (Nair, Chougule et al. 2025)
│   │   ├── dataset/              imta-cirkpi-lci.csv, parameters.csv
│   │   ├── dataset_properties.csv  name, version, UDI, counts
│   │   ├── metadata/             metadata.csv (dataset, authors, background, licence, sources, glossary)
│   │   ├── network/              directed graph of the inventory (GraphML)
│   │   ├── dependencies/         none
│   │   └── environment.yml
│   └── openlca_results/          aggregated openLCA results (ecoinvent 3.7, EF 3.1) – see README there
├── tool/
│   ├── kpi_tool.py               Python KPI decision tool (reads data/lci, writes kpi_results.csv)
│   ├── factors_illustrative.csv  illustrative impact factors (replace with your own per-unit LCA results)
│   ├── kpi_results.csv           output of kpi_tool.py
│   └── IMTA_KPI_decision_tool.xlsx  same workflow in Excel (14 tabs, formulas, charts)
├── openlca/
│   ├── IMTA_example_runnable_openLCA.zip   self-contained JSON-LD model (illustrative factors, runs without ecoinvent)
│   ├── KOMAL_imta_template_ecoinvent37.zip  JSON-LD template for ecoinvent 3.7 (inputs to be linked)
│   └── LCI_entry_sheet_ecoinvent37.xlsx     row-by-row entry sheet with providers and locations
├── figures/
└── sources/
    ├── REFERENCES.md
    └── references.bib
```

## How to use

**Python KPI tool**
```bash
pip install -r requirements.txt
python tool/kpi_tool.py                              # illustrative factors
python tool/kpi_tool.py --factors my_factors.csv     # your own per-unit factors from openLCA
```
To get real factors: in openLCA, calculate **1 unit** of each input (e.g. 1 kWh of
`market for electricity, low voltage | PT`) with EF 3.1 and enter the result in a copy of
`factors_illustrative.csv`.

**openLCA**
- `IMTA_example_runnable_openLCA.zip`: create an empty database → *File → Import → Linked Data (JSON-LD)* →
  open *Product systems → IMTA example* → Calculate with *IMTA example method (illustrative)*, economic allocation.
  Expected: 2.125 kg CO2-eq and 0.0725 kg N-eq per kg sea bream (scenario C) – identical to the Python and Excel tools.
- For ecoinvent 3.7: use the entry sheet or the template and **choose each provider manually**.

## Related publications

- Hala, A. F., Chougule, K., et al. (2024). Life cycle assessment of integrated multi-trophic aquaculture: A review on methodology
  and challenges for its sustainability evaluation. *Aquaculture*, 590, 741035. – basis for the functional unit and allocation choices.
- Nair, R. R., Chougule, K. M., Gomez, J. C., & Brand-Daniels, U. (2025). *Journal of Cleaner Production*, 520, 146120. – LCI format (below).

## LCI format

The inventory follows the **LCIS2024** schema for publishing and sharing foreground LCIs
(dataset, dataset properties, metadata, dependencies, network, environment):

> Nair, R. R., Chougule, K. M., Gomez, J. C., & Brand-Daniels, U. (2025).
> A generalized schema to publish and share life cycle inventories (LCI): Exemplary case of an aviation fuel supply chain.
> *Journal of Cleaner Production*, 520, 146120. https://doi.org/10.1016/j.jclepro.2025.146120

The original LCIS tool by the first author is available at https://doi.org/10.5281/zenodo.12200857.
This repository applies the schema manually to a new sector (aquaculture); it does not use or modify that tool.

## Data licence and ecoinvent

- ecoinvent data are licensed and are **not redistributed** here. Only dataset **names** and **aggregated**
  impact results (totals and grouped contributions) are included.
- Recalculating with ecoinvent requires your own ecoinvent licence.

## Author

Komal Mallesh Chougule – LCA, circular economy and LCI data structuring.
Feedback and corrections are welcome via issues.
